# Connect the AI to your reference manuals (RAG) — setup

This makes the Study Assistant and Podcast Studio read your **actual FDNY manuals**
and answer with citations, using Supabase as the backend. Your Anthropic key stays on
the server, never in the webpage.

**How the pieces fit:** you load your PDFs into a Supabase database once (the *ingest*
step). When someone asks a question, the app sends it to your Supabase `/ask` function,
which finds the most relevant manual passages and asks Claude to answer from them.

Everything on the app side is already built. Below is the part only you can do,
because it needs your accounts and your (copyrighted) PDFs.

---

## What you need

- A **Supabase** account and a project (free tier is fine to start).
- An **Anthropic API key** (from console.anthropic.com).
- **Node.js 18+** on your computer.
- The **Supabase CLI**: `npm install -g supabase` (then `supabase login`).
- Your **authorized** manual PDFs.

Files referenced below are in this repo: `supabase/schema.sql`,
`supabase/functions/ask/`, `supabase/functions/ingest/`, and `ingest/`.

---

## Step 1 — Create the database (2 min)

1. Open your Supabase project → **SQL Editor** → **New query**.
2. Paste the entire contents of `supabase/schema.sql` and click **Run**.

That creates the `documents` table, the vector index, and the search function.

## Step 2 — Set your secrets (2 min)

Pick a long random string for `APP_TOKEN` (e.g. from a password generator). In a
terminal, from the repo root:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF     # find the ref in your project URL/settings
supabase secrets set ANTHROPIC_API_KEY=sk-ant-your-key
supabase secrets set APP_TOKEN=your-long-random-token
# optional — set the model the backend uses:
supabase secrets set ANTHROPIC_MODEL=claude-sonnet-4-6
```

## Step 3 — Deploy the two functions (2 min)

```bash
supabase functions deploy ask --no-verify-jwt
supabase functions deploy ingest --no-verify-jwt
```

Your URLs are now:

- **Ask:**    `https://YOUR_PROJECT_REF.functions.supabase.co/ask`
- **Ingest:** `https://YOUR_PROJECT_REF.functions.supabase.co/ingest`

## Step 4 — Load your PDFs (the ingest step)

```bash
cd ingest
npm install
mkdir -p manuals            # drop your authorized PDFs in here
cp files.example.json files.json
```

Edit `files.json` so each PDF is tagged with a **topic** and the **ranks** it applies
to (topic/rank values are listed in the file's comment and in `content/README.md`).
Then run:

```bash
# optional first: parse & chunk without uploading, to sanity-check
node ingest.mjs --dry-run

# real upload:
INGEST_URL="https://YOUR_PROJECT_REF.functions.supabase.co/ingest" \
APP_TOKEN="your-long-random-token" \
node ingest.mjs
```

You'll see each file's page and chunk counts and an upload tally. Re-run anytime you
add manuals. To start clean, run `truncate documents restart identity;` in the SQL
Editor first.

## Step 5 — Connect the app (1 min)

1. Open your hosted app → **Settings** (gear, top-right).
2. Under **Manuals backend**, paste:
   - **Backend /ask URL** = your `/ask` URL from Step 3
   - **App token** = the same `APP_TOKEN`
3. **Save.**

Now open **Study Assistant** — it should say "Manuals backend connected," and answers
will cite the source passages. In **Podcast Studio**, leaving the source box empty will
script an episode from the ingested manuals for the topics you pick.

---

## Good to know

- **First call may be slow** (a few seconds) while the embedding model warms up.
- **Security / copyright:** the manuals now live in your private Supabase project — good.
  The `APP_TOKEN` deters casual abuse, but anyone with your site + token can query. For
  sensitive material, also put the *site* behind access control (e.g. host on a service
  with password protection, or a private deployment) and change the CORS line in
  `ask/index.ts` from `*` to your site's exact origin, then redeploy.
- **Cost:** embeddings run free inside Supabase (gte-small). You pay only for Claude
  usage on `/ask`, plus Supabase compute. Small study-group usage is inexpensive.
- **Never commit** `ingest/files.json`, `ingest/manuals/`, or your tokens — the included
  `.gitignore` already excludes them.
