// ingest.mjs — load your FDNY reference PDFs into the RAG backend.
//
// Usage:
//   1) Put your authorized PDFs in ./manuals
//   2) Copy files.example.json -> files.json and tag each PDF (topic + ranks)
//   3) Set two env vars, then run:
//        INGEST_URL="https://YOUR-PROJECT.functions.supabase.co/ingest" \
//        APP_TOKEN="your-long-random-token" \
//        node ingest.mjs
//
//   Add --dry-run to parse & chunk without uploading (prints a summary).
//
// Requires Node 18+ (built-in fetch) and: npm install

import { readFileSync, readdirSync, existsSync } from "node:fs";
import { join, extname, basename } from "node:path";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const pdfParse = require("pdf-parse");

const MANUALS_DIR = "./manuals";
const CHUNK_CHARS = 3500;   // ~900 tokens
const OVERLAP = 400;        // context carried between chunks
const BATCH = 20;           // chunks per upload request

const DRY = process.argv.includes("--dry-run");
const INGEST_URL = process.env.INGEST_URL;
const APP_TOKEN = process.env.APP_TOKEN;

if (!DRY && (!INGEST_URL || !APP_TOKEN)) {
  console.error("Set INGEST_URL and APP_TOKEN env vars (or use --dry-run). See the header of this file.");
  process.exit(1);
}

// Per-file tags: { "file.pdf": { title, topic, ranks:[...] } }
let tags = {};
if (existsSync("./files.json")) tags = JSON.parse(readFileSync("./files.json", "utf8"));
else console.warn("No files.json found — every PDF will be tagged with all ranks and no topic. Copy files.example.json to files.json to tag them.");

function chunkText(text) {
  const clean = text.replace(/\r/g, "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  const chunks = [];
  let i = 0;
  while (i < clean.length) {
    let end = Math.min(i + CHUNK_CHARS, clean.length);
    // prefer to break on a paragraph/sentence boundary
    if (end < clean.length) {
      const slice = clean.slice(i, end);
      const brk = Math.max(slice.lastIndexOf("\n\n"), slice.lastIndexOf(". "));
      if (brk > CHUNK_CHARS * 0.5) end = i + brk + 1;
    }
    const piece = clean.slice(i, end).trim();
    if (piece) chunks.push(piece);
    i = end - OVERLAP;
    if (i < 0) i = 0;
    if (end === clean.length) break;
  }
  return chunks;
}

async function upload(items) {
  const r = await fetch(INGEST_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-app-token": APP_TOKEN },
    body: JSON.stringify({ items }),
  });
  if (!r.ok) throw new Error("ingest " + r.status + ": " + (await r.text()).slice(0, 200));
  return r.json();
}

const files = existsSync(MANUALS_DIR)
  ? readdirSync(MANUALS_DIR).filter((f) => extname(f).toLowerCase() === ".pdf")
  : [];

if (!files.length) { console.error(`No PDFs found in ${MANUALS_DIR}`); process.exit(1); }

let totalChunks = 0, totalUploaded = 0;

for (const file of files) {
  const meta = tags[file] || {};
  const title = meta.title || basename(file, ".pdf");
  const topic = meta.topic || null;
  const ranks = Array.isArray(meta.ranks) ? meta.ranks : null; // null = all ranks

  process.stdout.write(`\n• ${file}  →  "${title}" [${topic || "no-topic"}] ${ranks ? ranks.join("/") : "all ranks"}\n`);
  const data = await pdfParse(readFileSync(join(MANUALS_DIR, file)));
  const chunks = chunkText(data.text || "");
  console.log(`  pages: ${data.numpages}   chunks: ${chunks.length}`);
  totalChunks += chunks.length;

  if (DRY) continue;

  const items = chunks.map((content, idx) => ({
    content,
    metadata: { title, topic, ranks, source: file, chunk: idx + 1 },
  }));

  for (let b = 0; b < items.length; b += BATCH) {
    const slice = items.slice(b, b + BATCH);
    const res = await upload(slice);
    totalUploaded += res.inserted || 0;
    process.stdout.write(`  uploaded ${Math.min(b + BATCH, items.length)}/${items.length}\r`);
  }
  process.stdout.write("\n");
}

console.log(`\nDone. ${files.length} file(s), ${totalChunks} chunk(s)${DRY ? " (dry run — nothing uploaded)" : `, ${totalUploaded} uploaded`}.`);
