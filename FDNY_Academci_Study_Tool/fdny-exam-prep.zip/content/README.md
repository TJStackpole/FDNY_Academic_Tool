# Content folder

Everything in this folder is **your** material. The app reads `manifest.json` at
startup and merges what it finds into the Reference Library, the Study Assistant's
grounding context, and the Diagrams & Video page.

> **Do not commit copyrighted FDNY manuals to a public repository.** Internal FDNY
> publications are intranet-only and copyrighted. Keep them in a **private** repo, or
> link to authorized copies rather than uploading the files. See "Connecting large
> study material" below.

## The two layers of "mapping"

1. **Reference material (the bibliography)** → `manifest.json` (this folder). This is
   *what each rank is tested on*. A rank-tagged bibliography ships here already,
   generated from the LT / CAPT / BC / DC bibliographies.
2. **Study items (the drills)** → the data arrays near the top of the `<script>` in
   `index.html` (`QUESTIONS`, `FLASHCARDS`, `SCENARIOS`, `ACRONYMS`, `TOPIC_NOTES`).
   You write these *from* the publications in layer 1.

Both layers key off the same `topic` IDs and `ranks`, so tagging is the whole mapping.

## Ranks

`Lieutenant`, `Captain`, `Battalion Chief`, `Deputy Chief` (spelled exactly).
Lieutenant and Captain share a base bibliography (Captain = LT + extra material);
Battalion Chief and Deputy Chief each have their own.

## Topic IDs (aligned to the FDNY publication categories)

| ID           | Publication category |
|--------------|----------------------|
| `auc`        | All Units Circulars |
| `engine`     | Basic Engine Operations |
| `comms`      | Communications Manual |
| `cfr`        | Certified First Responder Manual |
| `emergency`  | Emergency Procedures |
| `evolutions` | Evolutions |
| `ffp`        | Firefighting Procedures |
| `mmd`        | Managing Members in Distress |
| `erp`        | HazMat & Emergency Response Plan |
| `hazmat`     | Hazmat |
| `ics`        | ICS Manual |
| `ladder`     | Ladder Company Operations |
| `marine`     | Marine Manual (Deputy Chief) |
| `regs`       | Regulations for the Uniform Force |
| `safety`     | Safety Bulletins |
| `training`   | Training Bulletins |
| `paids`      | PA/IDs |
| `firecode`   | NYC Fire Code (public reference) |

## `manifest.json` schema

```json
{
  "references": [
    {
      "title": "Firefighting Procedures — Books 1-10",
      "topic": "ffp",
      "ranks": ["Lieutenant", "Captain", "Battalion Chief", "Deputy Chief"],
      "file": "content/ffp-books.pdf",
      "note": "Chapters/omits per your NOE"
    }
  ],
  "videos": [
    { "title": "Vertical ventilation", "topic": "training",
      "ranks": ["Lieutenant"], "embed": "https://www.youtube.com/embed/VIDEO_ID" }
  ]
}
```

| Field   | Required | Notes |
|---------|----------|-------|
| `title` | yes | Display name. |
| `topic` | yes | One of the IDs above. |
| `ranks` | no  | Ranks this item is on the bibliography for. Omit = all ranks. |
| `file`  | no  | Path/URL to a PDF **you host** (not a public repo). |
| `url`   | no  | External link instead of a hosted file. |
| `note`  | no  | Scope note (books/chapters/omits). |

An entry with no `file` and no `url` shows as "Add PDF" — it's a checklist item
until you point it at a document.

## Connecting large study material

The manuals themselves are hundreds of MB, copyrighted, and intranet-only. **They do
not go in the repo.** You have two ways to connect them:

### Option A — Link-out reading list (works today, no backend)
Host the authorized PDFs somewhere access-controlled (a **private** repo, department
intranet, Google Drive/SharePoint with permissions, or S3), then put each link in the
matching `manifest.json` entry's `file`/`url`. The Reference Library becomes a
per-rank reading list that opens the real documents. The AI assistant is grounded in
the *titles and notes* here, not the full text.

### Option B — AI that reads the actual manuals (RAG backend)
To have the assistant answer *from the manuals' text* and generate questions from
them, the content must be searchable at query time. A browser can't hold or send
gigabytes, so you add a small backend that does Retrieval-Augmented Generation:

1. **Ingest once:** chunk each manual's text and store embeddings in a vector DB.
2. **At query time:** embed the question, retrieve the most relevant chunks, and send
   only those to the model.

This also fixes API-key exposure, because the key lives in the backend, not the page.
A low-cost stack that fits GitHub Pages: a serverless function + **Supabase
(pgvector)**. Point the app's assistant/podcast calls at your `/ask` endpoint instead
of calling Anthropic directly.

## Prototype mode — bundled Lieutenant manual (no backend)

For a quick prototype you can skip the backend entirely and bundle one rank's manual
directly in the app:

- **`content/lt-knowledge.json`** holds the Lieutenant manual as ~3,600 page-tagged
  text chunks. When the rank is set to **Lieutenant** and no backend is configured, the
  app loads this file on first AI use, searches it in the browser, and answers the Study
  Assistant / Podcast Studio with **page citations** — no server needed.
- Only Lieutenant is bundled; other ranks fall back to the general study notes.
- To regenerate it later (new edition, or to add a rank), re-run the extraction that
  produced it: read the PDFs with `pdftotext`, chunk to ~1,800 characters with page
  numbers, and write the same `{rank, source, pages, chunks:[{i,p,t}]}` shape.

> **Copyright:** this file contains the actual manual text. Keep the repository
> **private**. Do not publish it. For a public or shared deployment, move the manual
> into the Supabase backend (see `RAG_SETUP.md`) instead of bundling it.
