// Supabase Edge Function: /ingest
// Receives batches of text chunks, embeds each with the built-in gte-small model,
// and stores them in the documents table. Called by the local ingest script.
//
// Deploy:  supabase functions deploy ingest --no-verify-jwt
// Secrets: APP_TOKEN must be set (same token the ingest script and app use).

import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type, x-app-token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  const token = req.headers.get("x-app-token") ?? "";
  if (!Deno.env.get("APP_TOKEN") || token !== Deno.env.get("APP_TOKEN"))
    return json({ error: "unauthorized" }, 401);

  let payload: any;
  try { payload = await req.json(); } catch { return json({ error: "bad json" }, 400); }

  const items: Array<{ content: string; metadata?: Record<string, unknown> }> = payload?.items ?? [];
  if (!Array.isArray(items) || items.length === 0) return json({ error: "no items" }, 400);

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  // deno-lint-ignore no-explicit-any
  const model = new (globalThis as any).Supabase.ai.Session("gte-small");

  const rows: any[] = [];
  for (const it of items) {
    const content = (it.content ?? "").toString().trim();
    if (!content) continue;
    const embedding = await model.run(content, { mean_pool: true, normalize: true });
    rows.push({ content, metadata: it.metadata ?? {}, embedding });
  }

  const { error } = await supabase.from("documents").insert(rows);
  if (error) return json({ error: String(error) }, 500);

  return json({ inserted: rows.length });
});
