// Supabase Edge Function: /ask
// Retrieves the most relevant manual passages for the question, then asks Claude
// to answer using ONLY those passages. The Anthropic key stays here (server-side).
//
// Deploy:  supabase functions deploy ask --no-verify-jwt
// Secrets: supabase secrets set ANTHROPIC_API_KEY=sk-ant-...  APP_TOKEN=your-long-random-token
// Optional: supabase secrets set ANTHROPIC_MODEL=claude-sonnet-4-6
//
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are injected automatically.

import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*", // tighten to your site's origin for production
  "Access-Control-Allow-Headers": "content-type, x-app-token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  // Simple shared-secret gate
  const token = req.headers.get("x-app-token") ?? "";
  if (!Deno.env.get("APP_TOKEN") || token !== Deno.env.get("APP_TOKEN"))
    return json({ error: "unauthorized" }, 401);

  let payload: any;
  try { payload = await req.json(); } catch { return json({ error: "bad json" }, 400); }

  const {
    messages = [],
    system = "",
    retrievalQuery = "",
    rank = null,
    topic = null,
    maxTokens = 1400,
  } = payload ?? {};

  const lastUser = [...messages].reverse().find((m: any) => m.role === "user");
  const query = (retrievalQuery || lastUser?.content || "").toString().slice(0, 2000);

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  // 1) Embed the query with the built-in gte-small model (384-dim)
  let matches: any[] = [];
  try {
    // deno-lint-ignore no-explicit-any
    const model = new (globalThis as any).Supabase.ai.Session("gte-small");
    const embedding = await model.run(query, { mean_pool: true, normalize: true });

    // 2) Retrieve the most relevant chunks, filtered by rank/topic
    const { data, error } = await supabase.rpc("match_documents", {
      query_embedding: embedding,
      match_count: 8,
      filter_rank: rank,
      filter_topic: topic,
    });
    if (error) throw error;
    matches = data ?? [];
  } catch (e) {
    return json({ error: "retrieval failed: " + String(e) }, 500);
  }

  // 3) Build context + source list from the retrieved passages
  const context = matches
    .map((m, i) => {
      const t = m.metadata?.title ?? m.metadata?.source ?? "Manual";
      const loc = m.metadata?.chunk != null ? ` (part ${m.metadata.chunk})` : "";
      return `[[${i + 1}]] ${t}${loc}\n${m.content}`;
    })
    .join("\n\n---\n\n");

  const sources = matches.map((m) => ({
    title: m.metadata?.title ?? m.metadata?.source ?? "Manual",
    topic: m.metadata?.topic ?? null,
    similarity: Number(m.similarity?.toFixed?.(3) ?? 0),
  }));

  const finalSystem =
    (system || "You are an FDNY promotion-exam study assistant.") +
    `\n\nRETRIEVED SOURCE PASSAGES (answer using these; cite them as [1], [2], ... ; if they do not cover the question, say so):\n\n` +
    (context || "(no relevant passages were found)");

  // 4) Generate with Claude
  const model = Deno.env.get("ANTHROPIC_MODEL") || "claude-sonnet-4-6";
  let answer = "";
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model,
        max_tokens: Math.min(8000, maxTokens),
        system: finalSystem,
        messages: messages.map((m: any) => ({ role: m.role, content: m.content })),
      }),
    });
    if (!r.ok) {
      const t = await r.text().catch(() => "");
      return json({ error: "anthropic " + r.status + ": " + t.slice(0, 200) }, 502);
    }
    const d = await r.json();
    answer = (d.content ?? []).filter((b: any) => b.type === "text").map((b: any) => b.text).join("\n").trim();
  } catch (e) {
    return json({ error: "generation failed: " + String(e) }, 500);
  }

  return json({ answer, sources });
});
