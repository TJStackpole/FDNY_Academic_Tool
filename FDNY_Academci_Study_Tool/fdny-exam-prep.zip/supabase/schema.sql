-- FDNY study tool — vector store for Retrieval-Augmented Generation (RAG)
-- Run this once in Supabase → SQL Editor. Uses the built-in gte-small model
-- (384-dimensional embeddings) so you need no separate embeddings provider.

-- 1) Enable pgvector
create extension if not exists vector;

-- 2) Table of manual chunks + embeddings
create table if not exists documents (
  id          bigserial primary key,
  content     text not null,               -- the chunk of manual text
  metadata    jsonb not null default '{}', -- { title, topic, ranks:[...], source, chunk }
  embedding   vector(384),                 -- gte-small dimension
  created_at  timestamptz default now()
);

-- 3) Similarity index (cosine). HNSW is good for read-heavy workloads.
create index if not exists documents_embedding_idx
  on documents using hnsw (embedding vector_cosine_ops);

-- Helps the rank/topic filters below
create index if not exists documents_metadata_idx
  on documents using gin (metadata);

-- 4) Retrieval function: nearest chunks, optionally filtered by rank and topic.
--    filter_rank matches when the chunk's metadata.ranks array contains that rank
--    (or when the chunk has no ranks = applies to all ranks).
create or replace function match_documents (
  query_embedding vector(384),
  match_count int default 8,
  filter_rank text default null,
  filter_topic text default null
)
returns table (
  id bigint,
  content text,
  metadata jsonb,
  similarity float
)
language sql stable
as $$
  select
    d.id,
    d.content,
    d.metadata,
    1 - (d.embedding <=> query_embedding) as similarity
  from documents d
  where
    (filter_rank is null
       or d.metadata->'ranks' is null
       or jsonb_typeof(d.metadata->'ranks') <> 'array'
       or d.metadata->'ranks' ? filter_rank)
    and (filter_topic is null or d.metadata->>'topic' = filter_topic)
  order by d.embedding <=> query_embedding
  limit match_count;
$$;

-- 5) Lock the table down. Only the service role (used by the Edge Functions)
--    can read/write; the public anon key cannot touch it directly.
alter table documents enable row level security;
-- (No policies added on purpose: service role bypasses RLS; anon gets nothing.)

-- To wipe and re-ingest everything later:
--   truncate documents restart identity;
