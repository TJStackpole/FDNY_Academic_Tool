# FDNY Promotion Exam Prep — Study Console

A single-file, browser-based study tool for FDNY promotion exams (**Lieutenant, Captain, Chief**). It runs entirely client-side, needs no build step, saves progress in your browser, and hosts for free on GitHub Pages.

> **Not affiliated with the FDNY or DCAS.** This project ships with **sample study content** for demonstration only. It does **not** contain official FDNY or DCAS material. See [Adding your own content](#adding-your-own-content) and [Legal & content policy](#legal--content-policy).

---

## Features

- **Command dashboard** — personalized to the selected rank: readiness score, readiness-over-time trend, accuracy, study streak, topic-mastery heatmap, study-activity bars, and plan-adherence tracking, with one-tap drills into weak topics.
- **Learning-style survey** — a VARK-style questionnaire that profiles the user as Visual / Auditory / Reading-Writing / Kinesthetic and weights recommendations and the study plan accordingly.
- **Adaptive study plan** — enter an exam date and minutes available per day; the app builds a topic-by-topic schedule matched to your learning style, and the dashboard tracks how closely you follow it.
- **Reference library** — links to public sources (2022 NYC Fire Code, FDNY rules, DCAS exam notices) and slots for your authorized internal manuals.
- **Study assistant (AI)** — a chat assistant grounded in the material you register; it answers questions, writes practice questions, explains concepts in plain English, and generates scenarios.
- **Flashcards** — 3D flip cards filtered by topic.
- **Practice tests** — timed, scored sets in the DCAS multiple-choice format; **save a test blueprint and regenerate a fresh question set from it** anytime.
- **Daily quiz** — Quick 3 / Daily 5 / Deep 10 lengths; completing one keeps your streak.
- **Scenarios** — officer decision-making prompts with grader key-points and model answers.
- **Podcast studio (AI)** — turn selected topics, a pasted chapter, or an entire pasted book into a narrated audio episode (~5 / 15 / 30 / 60 min) that explains complex topics simply, played aloud in the browser with speed and voice controls.
- **Diagrams & video** — animated explainers (ICS span of control, RECEO-VS, fire-growth curve) plus embeddable video slots the FDNY can populate.
- **Acronyms & mnemonics** — a searchable built-in library **plus a builder** so students create their own mnemonics and save them to the appropriate chapter/topic.

Everything except the two AI features works fully offline. The pass mark modeled throughout is **70%**, and the app notes the DCAS scoring split (test = 50% of final score; seniority + awards = the other 50%).

---

## Run it locally

Because the AI calls use `fetch`, open it through a local web server rather than `file://`:

```bash
# from the project folder
python3 -m http.server 8000
# then open http://localhost:8000
```

Any static server works. All non-AI features work offline once loaded.

---

## Deploy to GitHub Pages

1. Create a new GitHub repository and upload these files, **keeping the folder structure** (`index.html` at the root, plus the `content/` folder).
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
4. Choose branch **`main`** and folder **`/ (root)`**, then **Save**.
5. Wait ~1 minute; your site appears at `https://<your-username>.github.io/<repo-name>/`.

That's it — no build, no server.

---

## Turning on the AI features when self-hosted

The **Study Assistant** and the **AI podcast scripting** call the Anthropic API.

- **Inside the Claude.ai artifact preview**, they work automatically.
- **On your own hosted site** (GitHub Pages, etc.), open the **Settings** gear (top-right) and paste your own **Anthropic API key**. It is stored **only in your browser's localStorage** and sent **only to Anthropic**. Without a key, the assistant explains how to add one, and the podcast studio falls back to building a shorter episode from the built-in notes.

> **Never commit your API key.** Do not put it in any file in the repo. Enter it at runtime via Settings. A key committed to a public repo is exposed to everyone.
>
> For a fully locked-down public deployment, proxy the Anthropic call through a small serverless function (e.g. Cloudflare Workers, Vercel, Netlify Functions) that holds the key server-side, and point `callClaude()` at that endpoint. This keeps the key off the client entirely.

---

## Adding your own content

The app reads an optional `content/manifest.json` at load time to register your reference PDFs and videos. See **[content/README.md](content/README.md)** for the schema. In short:

- Drop authorized PDFs into `content/` and list them under `references`.
- Add video embed URLs under `videos`.
- Registered references also feed the Study Assistant and Podcast Studio as grounding context.

To replace the **sample question bank, flashcards, scenarios, acronyms, and podcast notes** with real content mapped to the official bibliographies, edit the data arrays near the top of the `<script>` in `index.html`: `QUESTIONS`, `FLASHCARDS`, `SCENARIOS`, `ACRONYMS`, and `TOPIC_NOTES`. Each item carries a `topic` field that must match one of the stable topic IDs in the `TOPICS` array — that is what maps your content cleanly onto the dashboard, plan, and filters.

---

## Legal & content policy

- **Not affiliated with, endorsed by, or connected to the FDNY or DCAS.**
- The **FDNY Maltese-cross insignia is a trademark of the City of New York.** This repo ships a generic placeholder emblem. Replace it with your own authorized artwork before any public or official use (see the comment above the emblem `<svg>` in `index.html`).
- **Internal FDNY manuals** (Communications, Probationary Firefighter, Regulations, HAZMAT, CFR-D, Ladder/Engine Operations, All Units Circulars) are distributed on the FDNY intranet and are **copyrighted**. **Do not commit them to a public repository.** Host them privately or link to authorized copies.
- The bundled study content is **illustrative general fire-service knowledge**, not a reproduction of any exam or manual.
- The code is released under the MIT License (see [LICENSE](LICENSE)); the license covers the **code only**, not any FDNY publications, trademarks, or content you add.
