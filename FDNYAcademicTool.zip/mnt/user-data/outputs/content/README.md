# Content folder

Everything in this folder is **your** material. The app reads `manifest.json` at
startup and merges what it finds into the Reference Library, the Study Assistant's
grounding context, and the Diagrams & Video page. Nothing here is committed by
default — you add it.

> **Do not commit copyrighted FDNY manuals to a public repository.** Internal FDNY
> publications are intranet-only and copyrighted. Keep them in a private repo, or
> link to authorized copies rather than uploading the files.

## `manifest.json` schema

```json
{
  "references": [
    {
      "title": "Engine Company Operations (authorized copy)",
      "topic": "engine",
      "file": "content/engine-ops.pdf",
      "note": "Chapters 1–6 in scope for this cycle"
    },
    {
      "title": "Some public bulletin",
      "topic": "circulars",
      "url": "https://example.gov/bulletin.pdf",
      "note": "Linked, not hosted here"
    }
  ],
  "videos": [
    {
      "title": "Ventilation coordination",
      "topic": "ladder",
      "embed": "https://www.youtube.com/embed/VIDEO_ID"
    }
  ]
}
```

### `references[]`

| Field   | Required | Description |
|---------|----------|-------------|
| `title` | yes      | Display name in the library. |
| `topic` | yes      | One of the topic IDs below. Controls filtering and grouping. |
| `file`  | one of `file`/`url` | Path to a PDF you placed in this folder (e.g. `content/engine-ops.pdf`). |
| `url`   | one of `file`/`url` | External link instead of a hosted file. |
| `note`  | no       | Short scope note shown under the title. |

### `videos[]`

| Field   | Required | Description |
|---------|----------|-------------|
| `title` | yes      | Caption under the player. |
| `topic` | yes      | One of the topic IDs below. |
| `embed` | yes      | An **embeddable** URL (e.g. a YouTube `/embed/` link), shown in an iframe. |

## Valid topic IDs

These are the stable IDs the whole app maps content onto. Use them exactly:

| ID             | Topic |
|----------------|-------|
| `firecode`     | NYC Fire Code (2022) |
| `comms`        | Communications Manual |
| `proby`        | Probationary Firefighter Manual |
| `regs`         | FDNY Regulations |
| `hazmat`       | HAZMAT Operations |
| `cfrd`         | CFR-D / First Responder |
| `ladder`       | Ladder Company Operations |
| `engine`       | Engine Company Operations |
| `circulars`    | All Units Circulars |
| `command`      | Incident Command / ICS |
| `construction` | Building Construction & Fire Behavior |

## Mapping content to the official bibliographies

To turn this from a demo into a real study tool, map each publication in your
rank's DCAS bibliography to one of the topic IDs above, then:

1. Add the publication (or a link) to `references[]` here.
2. Replace the sample `QUESTIONS`, `FLASHCARDS`, `SCENARIOS`, `ACRONYMS`, and
   `TOPIC_NOTES` arrays in `index.html` with real items, each tagged with the
   matching `topic` ID.

Because every feature keys off those same topic IDs, your content flows into the
dashboard, plan, flashcards, quizzes, and podcast automatically.
